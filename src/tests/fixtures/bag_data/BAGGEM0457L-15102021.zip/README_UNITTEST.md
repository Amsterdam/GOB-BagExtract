# Modified BAGExtract data

Data in this zip file is changed to make the size of the archive smaller.
XML's in the following zip files only have a few mutations out of many thousands:

* 0457OPR15102021
* 0457VBO15102021


